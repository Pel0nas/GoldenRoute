package ServerSide;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "operation_details")
public class OperationDetails {
    @Id
    @JsonProperty("cargo_weight")
    private double cargoWeight;

    @JsonProperty("min_takeoff_distance")
    private double minTakeoffDistance;

    @JsonProperty("cargo_to_destroy")
    private double cargoToDestroy;

    @JsonProperty("takeoff_time")
    private double takeoffTime;

    public void setCargoWeight(double cargoWeight) {
        this.cargoWeight = cargoWeight;
    }

    public void setMinTakeoffDistance(double minTakeoffDistance) {
        this.minTakeoffDistance = minTakeoffDistance;
    }

    public void setCargoToDestroy(double cargoToDestroy) {
        this.cargoToDestroy = cargoToDestroy;
    }

    public void setTakeoffTime(double takeoffTime) {
        this.takeoffTime = takeoffTime;
    }
}

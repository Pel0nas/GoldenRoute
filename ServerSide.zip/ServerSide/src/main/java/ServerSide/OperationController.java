package ServerSide;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/operations")
public class OperationController {
    private OperationService operationService;

    @Autowired
    public OperationController(OperationService operationService) {
        this.operationService = operationService;
    }

    @GetMapping("/{cargoWeight}")
    public ResponseEntity<OperationDetails> getOperationDetailsByCargoWeight(@PathVariable double cargoWeight) {
        OperationDetails operationDetails = operationService.getOperationDetailsByCargoWeight(cargoWeight);
        return new ResponseEntity<>(operationDetails, HttpStatus.OK);
    }

    @PutMapping("/{cargoWeight}")
    public ResponseEntity<String> updateOperationDetailsByCargoWeight
            (@PathVariable double cargoWeight, @RequestBody OperationDetails operationDetails) {
        return new ResponseEntity<>("Operation details updated successfully", HttpStatus.OK);
    }
}
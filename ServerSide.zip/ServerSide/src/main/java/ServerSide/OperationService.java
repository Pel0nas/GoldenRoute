package ServerSide;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OperationService {
    @Autowired
    private OperationRepository operationRepository;

    public OperationDetails getOperationDetailsByCargoWeight(double cargoWeight) {
        return this.operationRepository.findById(cargoWeight).orElseGet(() -> addOperationDetails(cargoWeight));
    }

    public OperationDetails addOperationDetails(double cargoWeight) {
        if (cargoWeight < 0) {
            throw new IllegalArgumentException("Cargo weight cannot be negative");
        }

        double acceleration = calcAcceleration(cargoWeight);
        double time = calcTakeoffTime(acceleration);
        double distance = calcTakeoffDistance(acceleration, time);

        OperationDetails operationDetails = new OperationDetails();
        operationDetails.setCargoWeight(cargoWeight);
        operationDetails.setTakeoffTime(calcTakeoffTime(acceleration));
        operationDetails.setMinTakeoffDistance(distance);

        if (isOverweight(cargoWeight)) {
            operationDetails.setCargoToDestroy(cargoToDestroy(cargoWeight));
        } else {
            operationDetails.setCargoToDestroy(0);
        }

        return this.operationRepository.save(operationDetails);
    }

    public static double calcAcceleration(double cargoMass) {
        final double PLANE_MASS = 35000;
        final double TOTAL_ENGINE_POWER = 100000;

        return TOTAL_ENGINE_POWER / (cargoMass + PLANE_MASS);
    }

    public static double calcTakeoffTime(double acceleration) {
        final double TAKEOFF_SPEED = 140;

        return TAKEOFF_SPEED / acceleration;
    }

    public static double calcTakeoffDistance(double acceleration, double time) {
        return 0.5 * acceleration * Math.pow(time, 2);
    }

    public static boolean isOverweight(double cargoMass) {
        return calcTakeoffTime(calcAcceleration(cargoMass)) > 60;
    }

    public static double cargoToDestroy(double cargoMass) {
        final double PLANE_MASS = 35000;
        final double TOTAL_ENGINE_POWER = 100000;
        final double MAX_TAKEOFF_TIME = 60;
        final double SPEED = 140;

        double maxCargoMass = (TOTAL_ENGINE_POWER / (SPEED / MAX_TAKEOFF_TIME)) - PLANE_MASS;

        return cargoMass - maxCargoMass;
    }
}

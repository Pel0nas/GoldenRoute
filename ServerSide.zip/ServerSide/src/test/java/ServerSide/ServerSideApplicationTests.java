//package ServerSide;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class ServerSideApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}

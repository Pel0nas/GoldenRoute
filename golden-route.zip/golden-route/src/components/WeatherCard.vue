<template>
    <div class="card">
      <div class="card-content">
        <h2 class="title">Weather overview</h2>
        <div class="field">
          <label class="label">Select Date:</label>
          <div class="control">
            <input class="input" type="date" v-model="selectedDate"/>
          </div>
        </div>
        <div v-if="filteredData">
          <h3 style="font-weight: bolder;">The operation at {{ selectedDate }} is good to go at these hours:</h3>
          <br>
          <div class="hour-row" v-for="(hour, index) in filteredData" :key="index">
            <p class="hour">{{ hour.time }}</p>
            <p class="temperature"> {{ hour.temperature_2m }}°C</p>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import axios from "@/api/api.js";
  
  export default {
    data() {
      return {
        selectedDate: null,
        filteredData: null,
        weatherData: null,
      };
    },
    watch: {
      async selectedDate() {
        await this.fetchWeatherData();
        this.filterData();
      },
    },
    methods: {
      filterData() {
        const time = this.weatherData.hourly.time;
        const temperature = this.weatherData.hourly.temperature_2m;
  
        this.filteredData = time.reduce((acc, cur, index) => {
          if (temperature[index] >= 15 && temperature[index] <= 30) {
            const hour = new Date(cur).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit"
            });
            acc.push({ time: hour, temperature_2m: temperature[index] });
          }
          return acc;
        }, []);
      },
      fetchWeatherData() {
        return new Promise((resolve, reject) => {
          axios
            .get(`https://api.open-meteo.com/v1/forecast?latitude=30&longitude=35&hourly=temperature_2m&current_weather=true&forecast_days=1&start_date=${this.selectedDate}&end_date=${this.selectedDate}`)
            .then(response => {
              this.weatherData = response.data;
              resolve();
            })
            .catch(error => {
              console.log("Error: ", error);
              reject(error);
            });
        });
      },
    },
  };
  </script>
  
  <style scoped>
  .card {
    width: 300px;
    margin: 20px;
  }
  
  .title {
    margin-bottom: 1rem;
  }
  
  .hour-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
  }
  
  .hour {
    margin: 0;
  }
  
  .temperature {
    margin: 0;
  }
  </style>
  
<template>    
  <div class="card">
    <div class="card-image">
    <figure class="image is-5by2">
      <img alt="airplane image" src="@/assets/Airplane.jpg"/>    </figure>
  </div>
    <div class="card-content">
      <h2 class="title is-4 has-text-centered">Calculate operation Details</h2>
      <div class="content">
        <div class="field has-addons">
          <div class="control" :class="{ 'has-icons-right': negativeError }">
            <input v-model="cargoWeight" type="number" placeholder="Enter cargo weight" class="input" @input="resetError" />
            <span class="icon is-small is-right" v-if="negativeError">
              <i class="fas fa-exclamation-circle has-text-danger"></i>
            </span>
          </div>
          <div class="control">
            <button @click="getOperationDetails" class="button is-info">Get Operation Details</button>
          </div>
        </div>
        <div class="has-text-centered" v-if="negativeError">
          <p class="has-text-danger">Can't enter negative numbers</p>
        </div>
        <div v-if="loading" class="has-text-centered">
          Loading operation details...
        </div>
        <div v-else>
          <div v-if="operationDetails">
            <p><strong>Cargo Weight:</strong> {{ operationDetails.cargo_weight }} kg</p>
            <p><strong>Cargo to Destroy:</strong> {{ operationDetails.cargo_to_destroy }} kg</p>
            <p><strong>Takeoff Time:</strong> {{ operationDetails.takeoff_time }} seconds</p>
            <p><strong>Min Takeoff Distance:</strong> {{ operationDetails.min_takeoff_distance }} m</p>
          </div>
          <div v-else class="has-text-centered">
            No operation details available.
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    operationDetails: {
      type: Object,
      default: null,
    },
  },
  data() {
    return {
      cargoWeight: "",
      loading: false,
      negativeError: false,
    };
  },
  methods: {
    getOperationDetails() {
      if (this.cargoWeight < 0) {
        this.negativeError = true;
        return;
      }
      this.negativeError = false;

      this.$emit('getOperationDetails', this.cargoWeight);
    },
    resetError() {
      this.negativeError = false;
    },
  },
};
</script>

<style scoped>
.card {
  width: 400px;
  margin: auto;
  margin-top: 2%;
}

.card-content {
  padding: 1rem;
}

.content {
  text-align: left;
}

.field {
  margin-top: 1rem;
  margin-bottom: 1rem;
  display: flex;
  justify-content: center;
}

.has-text-centered {
  text-align: center;
}

.has-icons-right .input {
  border-color: #f14668 !important;
  box-shadow: none !important;
}

.has-icons-right .icon.is-right {
  color: #f14668 !important;
}
</style>

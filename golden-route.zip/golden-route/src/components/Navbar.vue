<template>
    <nav class="navbar is-info" role="navigation" aria-label="main navigation">
      <div class="navbar-brand">
        <a class="navbar-item" href="/">
          <span class="navbar-item-title">{{ title }}</span>
        </a>
      </div>
    </nav>
  </template>
  
  <script>
  export default {
    name: 'Navbar',
    props: {
      title: {
        type: String,
        required: true,
      },
    },
  };
  </script>
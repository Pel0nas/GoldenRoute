<template>
  <div class="home">
    <div class="main-card">
      <div class="card">
        <div class="card-content">
          <div class="columns">
            <div class="column is-8">
              <OperationDetailsCard :operationDetails="operationDetails" @getOperationDetails="getOperationDetails" />
            </div>
            <div class="column is-4">
              <WeatherCard/>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import OperationDetailsCard from '@/components/OperationDetailsCard.vue';
import WeatherCard from '@/components/WeatherCard.vue';
import axios from "@/api/api.js";

export default {
  name: "HomeView",
  components: {
    OperationDetailsCard,
    WeatherCard,
  },
  data() {
    return {
      operationDetails: null,
    };
  },
  methods: {
    getOperationDetails(cargoWeight) {
      this.operationDetails = null;
      this.$emit('loading', true);
      axios
        .get(`/operations/${cargoWeight}`)
        .then(response => {
          this.operationDetails = response.data;
        })
        .catch(error => {
          console.error(error);
        })
        .finally(() => {
          this.$emit('loading', false);
        });
    },
  },
};
</script>

<style scoped>
.main-card {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: flex-start;
}

.card {
  width: 80%;
  background-color: #ffffff;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}
</style>

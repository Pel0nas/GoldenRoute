<template>
  <div id="app">
    <Navbar title="Golden Route" />
    <HomeView />
  </div>
</template>


<script>
import Navbar from "@/components/Navbar.vue";
import HomeView from "./views/HomeView.vue";

export default {
  name: "App",
  components: {
    Navbar,
    HomeView,
},
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
